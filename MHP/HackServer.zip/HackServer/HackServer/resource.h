//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HackServer.rc
//
#define IDC_MYICON                      2
#define IDD_HACKSERVER_DIALOG           102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_HACKSERVER                  107
#define IDI_SMALL                       108
#define IDC_HACKSERVER                  109
#define IDR_MAINFRAME                   128
#define ID_DATABASE_RELOAD              32771
#define ID_DATABASE_UPDATEINTENALLIST   32772
#define IDM_RELOAD                      32773
#define IDM_UPDATE                      32774
#define ID_DATABASE_BLACKLIST           32775
#define ID_RELOAD_DUMP                  32776
#define IDM_DUMP_RELOAD                 32777
#define ID_RELOAD_CRC32                 32778
#define IDM_RELOAD_DUMP                 32779
#define ID_RELOAD_CHECKSUM              32780
#define ID_RELOAD_BLACKLIST             32781
#define IDM_RELOAD_CHECKSUM             32782
#define IDM_RELOAD_BLACKLIST            32783
#define ID_RELOAD_RELOADCONFIG          32784
#define IDM_RELOAD_WINDOW               32785
#define IDM_RELOAD_CONFIG               32786
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
