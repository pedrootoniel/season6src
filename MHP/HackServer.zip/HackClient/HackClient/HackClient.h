#pragma once

extern HINSTANCE hins;
