//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HackServer.rc
//
#define IDC_MYICON                      2
#define IDD_HACKSERVER_DIALOG           102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDC_HACKSERVER                  109
#define IDC_HACKSERVERSCREEN            110
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       130
#define IDD_DIALOG1                     131
#define IDM_SCREEN                      132
#define IDD_INFO_DIALOG                 133
#define IDD_DIALOG2                     137
#define IDD_LICENSE_BOX                 137
#define IDC_LIST1                       1000
#define IDC_LIST_IP                     1002
#define ID_RELOAD                       1003
#define ID_DESKTOP                      1004
#define IDC_BUTTON1                     1004
#define IDC_LIST_IP2                    1005
#define IDC_LIST_HWID                   1005
#define IDC_EDIT1                       1005
#define ID_DATABASE_RELOAD              32771
#define ID_DATABASE_UPDATEINTENALLIST   32772
#define IDM_RELOAD                      32773
#define IDM_UPDATE                      32774
#define IDM_BANNED                      32774
#define ID_DATABASE_BLACKLIST           32775
#define ID_RELOAD_DUMP                  32776
#define IDM_DUMP_RELOAD                 32777
#define ID_RELOAD_CRC32                 32778
#define IDM_RELOAD_DUMP                 32779
#define ID_RELOAD_CHECKSUM              32780
#define ID_RELOAD_BLACKLIST             32781
#define IDM_RELOAD_CHECKSUM             32782
#define IDM_RELOAD_BLACKLIST            32783
#define ID_RELOAD_RELOADCONFIG          32784
#define IDM_RELOAD_WINDOW               32785
#define IDM_RELOAD_CONFIG               32786
#define ID_OTHER_BANNED                 32787
#define ID_OTHER_DELETETEMPORARYBANS    32788
#define ID_OTHER_DELETETEMPBANS         32789
#define ID_OTHER_SCREEN                 32790
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
